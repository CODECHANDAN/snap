const apiKey = '8c83f3d2490b5bd00e801a9cd1883fae';
export default apiKey;